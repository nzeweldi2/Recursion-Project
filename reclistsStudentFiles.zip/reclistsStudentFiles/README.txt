Every function works correctly except for list union total reverse. Also I coded them as neatly as possible.
Total reverse only returns for top levels like the function that was provided. List union does not
prevent duplicates from being added to new list.